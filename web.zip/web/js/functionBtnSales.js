//
// 
//
function home() {
    window.open('/docudigital/index.jsp');
}
function volver() {
    history.back();
}
function closeOption() {
    ventana = window.self;
    ventana.opener = window.self;
    ventana.close();
    
}
function login() {
    window.close();
    window.open('/docudigital/index.jsp');
}
function imprimir(niv,alu,usu) {
    window.open('tools/reportPDFcert.jsp?n='+niv+'&a='+alu+'&u='+usu, '_blank');
}
