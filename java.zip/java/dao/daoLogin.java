/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.login;
import controller.Sql;
import controller.connectDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * 
 */
public class daoLogin {
    
    public static String addUser(login lg){
        String message = "";
        String sql = "INSERT INTO usuario(nombres,apellidos,correo,acceso,clave) "
                    + "VALUES('" + lg.getNombres() + "','" + lg.getApellidos() + "','" + lg.getCorreo() + "','" + lg.getUsuario() + "','"+lg.getClave()+"')";
               message = Sql.ejecuta(sql);
        return message;
    }
    
    public static String updUser(login lg){
        String message = "";
        String sql = "UPDATE usuario SET nombres='"+lg.getNombres()+"',apellidos='"+lg.getApellidos()+"',correo='"+lg.getCorreo()+"',acceso='"+lg.getUsuario()+"',clave='"+lg.getClave()+"' "
                    + "WHERE idUsuario='" +lg.getIduser()+"'";
               message = Sql.ejecuta(sql);
        return message;
    }
    
    public static String delUser(login lg){

        String sql = "DELETE FROM usuario WHERE idUsuario='" +lg.getIduser()+"'";
        return Sql.ejecuta(sql);
    }
    
    public boolean validateUserAccess(String txtuser, login usu){
        boolean isOk = false;
        String sql = "SELECT correo FROM usuario WHERE acceso='"+txtuser+"'";
        if(Sql.recordFound(sql)){
            isOk = true;
        } else {
            isOk = false;
        }
        return isOk;
    }
    
    public boolean validatePasswordAccess(String pass, String txtuser){
        boolean isOk = true;
        String sql = "SELECT clave FROM usuario WHERE clave='"+pass+"'";
        if(Sql.recordFound(sql)){
            isOk = true;
        } else {
            isOk = false;
        }
        return isOk;
    }
    
    public String captureTypeAccess(String txtuser){
        String sql = "SELECT tipo FROM usuario WHERE acceso='"+txtuser+"'";
        return Sql.getCampo(sql).toString();
    }
    
    public String captureIdAccess(String txtuser){
        String sql = "SELECT idUsuario FROM usuario WHERE acceso='"+txtuser+"'";
        return Sql.getCampo(sql).toString();
    }
    
    public static ArrayList<login> getAllUsers(){

        Connection cn = null;
        Statement st = null;
        ResultSet rs = null;
        ArrayList<login> listUser = new ArrayList<login>();
        String sql = "SELECT correo,usuario,clave FROM usuario";
        try {
            daoLogin dao = new daoLogin();
            connectDB db = new connectDB();
            cn = db.getConnection();
            if (cn != null) {
                st = cn.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()){
                                        
                    login u = new login(dao);
                    
                    u.setCorreo(rs.getString(1));
                    u.setUsuario(rs.getString(2));
                    u.setClave(rs.getString(3));

                    listUser.add(u);

                }
                rs.close();
                st.close();
                cn.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if ((cn != null) || (rs != null) || (st != null) ) {
                try {
                    rs.close(); st.close(); cn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
        return listUser;
    }
    
}
