/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.solicitud;
import controller.Sql;
import controller.connectDB;
import controller.convert;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * 
 */
public class daoSolicitud {
    public static String addSolicitud(solicitud sol){
        String message = "";
        String sql = "INSERT INTO solicitud(idUsuario,idAlumno,dni,telefono,nivel,motivo) "
                    + "VALUES('" + sol.getIdusuario() + "','"+sol.getIdalumno() + "','"+sol.getDni() + "','"+sol.getTelefono() + "','"+sol.getNivel() + "','"+sol.getMotivo()+"')";
               message = Sql.ejecuta(sql);
        return message;
    }
    
    public static String updSolicitud(solicitud sol){
        String message = "";
        String sql = "UPDATE solicitud SET idUsuario='"+sol.getIdusuario()+"',idAlumno='"+sol.getIdalumno()+"',dni='"+sol.getDni()+"',telefono='"+sol.getTelefono()+"',nivel='"+sol.getNivel()+"',motivo='"+sol.getMotivo()+"' "
                    + "WHERE idSolicitud=" +sol.getIdsolicitud();
               message = Sql.ejecuta(sql);
        return message;
    }
    
    public static String delSolicitud(solicitud sol){
        String sql = "DELETE FROM solicitud WHERE idSolicitud="+sol.getIdsolicitud();
        return Sql.ejecuta(sql);
    }
    
    public static String lockSolicitud(solicitud sol){
        String sql = "UPDATE usuario SET tipo='V' WHERE idUsuario="+sol.getIdusuario();
        return Sql.ejecuta(sql);
    }
    
    public static String unlockSolicitud(solicitud sol){
        String sql = "UPDATE usuario SET tipo='S' WHERE idUsuario='"+sol.getIdusuario()+"'";
        return Sql.ejecuta(sql);
    }
    
    public static ArrayList<solicitud> getSolicitud(String idreg){

//        String strFixed = "<button type='button' class='btn' data-toggle='modal' data-tooltip='true' data-placement='bottom' ";

        String[][] dataButtons = {{"<button type='button' class='btn btn-xs modificar' data-toggle='modal' data-placement='bottom' title='Visualizar la solicitud' data-target='#lstSolicitud'","><i class='fa fa-edit'></i></button>"},{"<button type='button' class='btn btn-danger btn-xs eliminar' data-toggle='modal' data-placement='bottom' title='Eliminar el registro' data-target='#delSolicitud'","><i class='fa fa-trash'></i></button>"}};
        Connection cn = null;
        Statement st = null;
        ResultSet rs = null;
        String dataUpdate = "";
        String dataDelete = "";

        ArrayList<solicitud> listRecords = new ArrayList<solicitud>();
        String sql = "";
        if (idreg.equals("A")){
            //             1             2         3           4     5          6        7             8             9           0                 1                          2              3                                   4         5          6          7           8           9           0            1          2
            sql = "SELECT s.idSolicitud,u.nombres,u.apellidos,s.dni,s.telefono,u.correo,n.descripcion,m.descripcion,s.idUsuario,s.idAlumno,CONCAT(a.nombres,' ',a.apellidos),s.nivel,CONCAT(s.nivel,s.idAlumno,'u',s.idUsuario),'A' FROM solicitud AS s,usuario AS u,alumno AS a,nivel AS n,motivo AS m WHERE s.idUsuario=u.idUsuario AND s.idAlumno=a.idAlumno AND s.nivel=n.nivel AND s.motivo=m.motivo ORDER BY s.idSolicitud";
        } else {
            int idus = convert.aEntero(idreg);
            //             1             2         3           4     5          6        7             8             9           0                 1                          2              3                                   4         5          6          7           8           9           0            1          2
            sql = "SELECT s.idSolicitud,u.nombres,u.apellidos,s.dni,s.telefono,u.correo,n.descripcion,m.descripcion,s.idUsuario,s.idAlumno,CONCAT(a.nombres,' ',a.apellidos),s.nivel,CONCAT(s.nivel,s.idAlumno,'u',s.idUsuario),'V' FROM solicitud AS s,usuario AS u,alumno AS a,nivel AS n,motivo AS m WHERE s.idUsuario=u.idUsuario AND s.idAlumno=a.idAlumno AND s.nivel=n.nivel AND s.motivo=m.motivo AND s.idUsuario="+idus+" ORDER BY s.idSolicitud";
            //sql = "SELECT s.idSolicitud,u.nombres,u.apellidos,s.dni,s.telefono,u.correo,n.descripcion,m.descripcion,s.idUsuario,s.idAlumno,CONCAT(a.nombres,' ',a.apellidos),s.nivel,CONCAT(s.nivel,CAST(s.idAlumno AS CHARACTER),'u',CAST(s.idUsuario AS CHARACTER)) FROM solicitud AS s,usuario AS u,alumno AS a,nivel AS n,motivo AS m WHERE s.idUsuario=u.idUsuario AND s.idAlumno=a.idAlumno AND s.nivel=n.nivel AND s.motivo=m.motivo AND s.idUsuario="+idus;
        }
        try {
            connectDB db = new connectDB();
            cn = db.getConnection();
            if (cn != null) {
                st = cn.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()){
                    solicitud sol = new solicitud();
                    
                    sol.setIdsolicitud(rs.getInt(1));                    
                    sol.setNombres(rs.getString(2));
                    sol.setApellidos(rs.getString(3));
                    sol.setDni(rs.getString(4));
                    sol.setTelefono(rs.getString(5));
                    sol.setCorreo(rs.getString(6));
                    sol.setNivel(rs.getString(7));
                    sol.setMotivo(rs.getString(8));
                    sol.setIdusuario(rs.getInt(9));
                    sol.setIdalumno(rs.getInt(10));
                    sol.setAlumno(rs.getString(11));
                    sol.setCodnivel(rs.getString(12));
                    //sol.setFiltro(rs.getString(13).toString());
                    sol.setFiltro(rs.getString(14));
                    //String filtro = sol.getCodnivel()+convert.aCadena(sol.getIdalumno())+"-";//+convert.aCadena(sol.getIdusuario());
                    //sol.setFiltro(rs.getString(12)+convert.aCadena(rs.getInt(10)));
                    //sol.setFiltro(filtro);
                    //sol.setFiltro(convert.aCadena(rs.getInt(9)));
//                    String caad = "-";
//                    String cniv = sol.getCodnivel();
//                    String cusu = convert.aCadena(rs.getInt(9));
//                    String calu = convert.aCadena(rs.getInt(10));
//                    String filtro = (cniv+calu+caad+cusu);//+"aa"+cusu;
//                    sol.setFiltro(filtro);
                    dataUpdate = dataButtons[0][0]+" data-id='"+rs.getInt(1)+"' data-idus='"+rs.getInt(9)+"' data-name='"+rs.getString(2)+"' data-aplldo='"+rs.getString(3)+"' data-dni="+rs.getString(4)+" data-idtelefono="+rs.getString(5)+" data-email="+rs.getString(6)+""+dataButtons[0][1];
                    dataDelete = dataButtons[1][0]+" data-id="+rs.getInt(1)+""+dataButtons[1][1];

                    sol.setCbuttons("&nbsp;&nbsp;"+dataUpdate+"&nbsp;&nbsp;"+dataDelete);

                    listRecords.add(sol);

                }
                rs.close(); st.close(); cn.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if ((cn != null) || (rs != null) || (st != null) ) {
                try {
                    rs.close(); st.close(); cn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
        return listRecords;
    }
}
