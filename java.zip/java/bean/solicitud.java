
package bean;

/**
 *
 * 
 */
public class solicitud {
    private int idsolicitud;
    private int idusuario;
    private int idalumno;
    private String dni;
    private String telefono;
    private String nivel;
    private String codnivel;
    private String motivo;
    // Adicionales
    private String nombres;
    private String apellidos;
    private String alumno;
    private String correo;
    private String filtro;
    private String cbuttons;
    
    public int getIdsolicitud() {
        return idsolicitud;
    }

    public void setIdsolicitud(int idsolicitud) {
        this.idsolicitud = idsolicitud;
    }

    public int getIdusuario() {
        return idusuario;
    }

    public int getIdalumno() {
        return idalumno;
    }

    public void setIdalumno(int idalumno) {
        this.idalumno = idalumno;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getAlumno() {
        return alumno;
    }

    public void setAlumno(String alumno) {
        this.alumno = alumno;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getCodnivel() {
        return codnivel;
    }

    public void setCodnivel(String codnivel) {
        this.codnivel = codnivel;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getCbuttons() {
        return cbuttons;
    }

    public void setCbuttons(String cbuttons) {
        this.cbuttons = cbuttons;
    }

    public String getFiltro() {
        return filtro;
    }

    public void setFiltro(String filtro) {
        this.filtro = filtro;
    }

}
