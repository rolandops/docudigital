
package bean;

/**
 *
 * 
 */
public class archivos {
    
}
