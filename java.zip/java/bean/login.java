package bean;

import dao.daoLogin;

/**
 *
 * 
 */
public class login {
    daoLogin dao;
    private int iduser;
    private String nombres;
    private String apellidos;
    private String correo;
    private String usuario;
    private String clave;

    public login(daoLogin dao) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.dao = dao;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
    public boolean validateUser(String txtUser, login usu){
        return dao.validateUserAccess(txtUser,usu);
    }
    public boolean validatePassword(String pass, String user){
        return dao.validatePasswordAccess(pass,user);
    }
    public String captureUserType(String txtUser){
        return dao.captureTypeAccess(txtUser);
    }
    public String captureUserId(String txtUser){
        return dao.captureIdAccess(txtUser);
    }
}
