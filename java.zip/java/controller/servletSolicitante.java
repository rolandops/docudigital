/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bean.solicitud;
import dao.daoSolicitud;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * 
 */
public class servletSolicitante extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet servletSolicitante</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet servletSolicitante at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
        String accion = request.getParameter("accion");
        String msg = null;
        solicitud sol = new solicitud();
        if (accion == null) {
            msg = "No es posible atenderlo";
        } else if (accion.compareTo("INS") == 0) {
            sol.setIdusuario(convert.aEntero(request.getParameter("idusu")));
            sol.setIdalumno(convert.aEntero(request.getParameter("codal")));
            sol.setDni(request.getParameter("dni"));
            sol.setTelefono(request.getParameter("telefono"));
            sol.setNivel(request.getParameter("nivel"));
            sol.setMotivo(request.getParameter("motivo"));
            if (!sol.getDni().equals("")) {
                msg = daoSolicitud.addSolicitud(sol);
            } else {
                msg = " Ingrese su correo electronico.. no puede estar vacio.";
            }
        } else if (accion.compareTo("DEL") == 0) {
            sol.setIdsolicitud(convert.aEntero(request.getParameter("id")));
            msg = daoSolicitud.delSolicitud(sol);
        } else if (accion.compareTo("VIEW") == 0) {
            //sol.setIdsolicitud(convert.aEntero(request.getParameter("idsolicitud")));
            sol.setIdusuario(convert.aEntero(request.getParameter("idusuario")));
            //sol.setIdalumno(convert.aEntero(request.getParameter("idalumno")));
            msg = daoSolicitud.lockSolicitud(sol);
        } else if (accion.compareTo("UNLOCK") == 0) {
            sol.setIdusuario(convert.aEntero(request.getParameter("idusu")));
            msg = daoSolicitud.unlockSolicitud(sol);
        }else {
            msg = "Solicitud no reconocida";
        }

        if (msg == null) {
            msg = "Solicitud atendida";
        }

        request.getSession().setAttribute("msg", msg);
        if (accion.compareTo("INS") == 0){
            sol.setCorreo(request.getParameter("correo"));
            response.sendRedirect("/docudigital/view/msgSolicitudOk.jsp?idu="+request.getParameter("idusu")+"&cor="+sol.getCorreo());
        } else if (accion.compareTo("DEL") == 0) {
            response.sendRedirect("view/crudSolicitud.jsp");
        } else if (accion.compareTo("VIEW") == 0) {
            int ialu = convert.aEntero(request.getParameter("idalumno"));
            String cniv = request.getParameter("nivel");
            //response.sendRedirect("tools/reportPDFcert.jsp?idal="+ialu);
            response.sendRedirect("tools/reportPDFcert.jsp?idal="+ialu+"&idus='"+cniv+"'");
        } else if (accion.compareTo("UNLOCK") == 0) {
            response.sendRedirect("/docudigital/index.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
