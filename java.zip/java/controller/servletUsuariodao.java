/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import bean.login;
import dao.daoLogin;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * 
 */
public class servletUsuariodao extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        String msg = null;
        daoLogin dao = new daoLogin();
        login lg = new login(dao);
        lg.setCorreo(request.getParameter("correo"));
//        lg.setNombres(request.getParameter("nombres"));
//            lg.setApellidos(request.getParameter("apellidos"));
//            lg.setUsuario(request.getParameter("user"));
//            lg.setClave(request.getParameter("clave"));
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet servletUsuariodao</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet servletUsuariodao at " + request.getContextPath() + "</h1>");
//            out.println("<h1>Servlet servletUsuariodao at " + lg.getNombres() + "</h1>");
//            out.println("<h1>Servlet servletUsuariodao at " + lg.getApellidos() + "</h1>");
//            out.println("<h1>Servlet servletUsuariodao at " + request.getParameter("correo") + "</h1>");
//            out.println("<h1>Servlet servletUsuariodao at " + request.getParameter("user") + "</h1>");
//            out.println("<h1>Servlet servletUsuariodao at " + request.getParameter("clave") + "</h1>");
//            out.println("<h1>Servlet servletUsuariodao at " + lg.getCorreo() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
        
        if (accion == null) {
            msg = "No es posible atenderlo";
        } else if (accion.compareTo("INS") == 0) {
            lg.setNombres(request.getParameter("nombres"));
            lg.setApellidos(request.getParameter("apellidos"));
            lg.setUsuario(request.getParameter("user"));
            lg.setClave(request.getParameter("clave"));
            if (!lg.getCorreo().equals("")) {
                msg = daoLogin.addUser(lg);
            } else {
                msg = " Ingrese su correo electronico.. no puede estar vacio.";
            }
        } else if (accion.compareTo("DEL") == 0) {            
            msg = daoLogin.delUser(lg);
        } else if (accion.compareTo("UPD") == 0) {
            lg.setUsuario(request.getParameter("user"));
            lg.setClave(request.getParameter("clave"));
            msg = daoLogin.updUser(lg);
        } else {
            msg = "Solicitud no reconocida";
        }

        if (msg == null) {
            msg = "Solicitud atendida";
        }

        request.getSession().setAttribute("msg", msg);        
        //response.sendRedirect("/docudigital/view/closeWindow.html");
        response.sendRedirect("/docudigital/index.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
