
package controller;

/**
 *
 * 
 */
public class convert {
    public static double aReal(String s) {
        return Double.valueOf(s).doubleValue();
    }
    
    public static double aFloat(String s) {
        return Float.valueOf(s).floatValue();
    }
    
    public static int aEntero(String s) {
        return Integer.valueOf(s).intValue();
    }

    public static String aCadena(double x) {
        return String.valueOf(x);
    }
    
    public static String aCadena(float x) {
        return String.valueOf(x);
    }
    
    public static String aCadena(int x) {
        return String.valueOf(x);
    }
    
    public static char aChar(String x) {
        return x.charAt(0);
    }
}
